const dbCollections = require("../collections");
const recipeCollectionObj = dbCollections.recipe;
const { v1: uuidv4 } = require("uuid");

function getValidId(id) {
  if (!id) {
    throw "Given recipe id is invalid";
  }

  if (typeof id != "object" && typeof id != "string") {
    throw "Provide recipe id of type object or string ";
  }

  return id;
}

function getValidString(str, variableName) {
  if (!str) {
    throw `Provided ${variableName} is invalid`;
  }

  if (typeof str != "string") {
    throw `Given ${str} is not a string`;
  }

  if (str.trim().length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return str;
}

function getValidArray(array, variableName) {
  if (!array) {
    throw `Provided ${variableName} is invalid`;
  }

  if (!Array.isArray(array)) {
    throw `Given ${array} is not an Array`;
  }

  if (array.length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return array;
}

function getValidStepsArray(array, variableName) {
  array = getValidArray(array, variableName);

  for (let step of array) {
    step = getValidString(step, "Recipe Step");
  }
  return array;
}

function getValidIngredientsArray(array, variableName) {
  array = getValidArray(array, variableName);

  for (let obj of array) {
    if (!obj || !obj["name"] || !obj["amount"]) {
      throw `Provided ${variableName} is invalid`;
    }
    if (typeof obj != "object") {
      throw `Given ${obj} is not an Object`;
    }

    if (Object.keys(obj).length != 2) {
      throw `Must provide only required fields.`;
    }

    if (obj["name"]) {
      obj["name"] = getValidString(obj["name"], "Ingredient Name");
    }

    if (obj["amount"]) {
      obj["amount"] = getValidString(obj["amount"], "Ingredient amount");
    }
  }
  return array;
}

async function getRecipeById(id) {
  id = getValidId(id);
  let recipeObj = await recipeCollectionObj();

  let recipeData = await recipeObj.findOne({ _id: id });

  if (recipeData === null) {
    throw `Error :Cannot find recipe with given id : ${id} into database`;
  }

  return recipeData;
}

async function getAllRecipe() {
  const recipeObj = await recipeCollectionObj();
  const allRecipeData = await recipeObj
    .find({}, { projection: { ingredients: 0, steps: 0 } })
    .toArray();

  if (allRecipeData === null) {
    throw `No recipe found in database`;
  }
  return allRecipeData;
}

async function createRecipe(title, ingredients, steps) {
  title = getValidString(title, "Recipe Name");
  ingredients = getValidIngredientsArray(ingredients, "Ingredients");
  steps = getValidStepsArray(steps, "Recipe Steps");

  let recipeSchema = {
    _id: uuidv4(),
    title: title,
    ingredients: ingredients,
    steps: steps,
  };

  let recipeObj = await recipeCollectionObj();

  let newRecipe = await recipeObj.insertOne(recipeSchema);

  if (newRecipe.insertedCount === 0) {
    throw `Error : Unable to add new recipe into database`;
  }

  return await this.getRecipeById(newRecipe.insertedId);
}

async function updateRecipe(id, title, ingredients, steps) {
  id = getValidId(id);
  title = getValidString(title, "Recipe Name");
  ingredients = getValidIngredientsArray(ingredients, "Ingredients");
  steps = getValidStepsArray(steps, "Recipe Steps");

  let recipeObj = await recipeCollectionObj();
  let recipeSchema = {
    title: title,
    ingredients: ingredients,
    steps: steps,
  };

  let updateRecipe = await recipeObj.updateOne(
    { _id: id },
    { $set: recipeSchema }
  );

  if (!updateRecipe.modifiedCount && !updateRecipe.matchedCount) {
    throw `Error : Unable to update recipe with id : ${id} into database`;
  }

  return await this.getRecipeById(id);
}

async function deleteRecipe(id) {
  id = getValidId(id);

  let recipeObj = await recipeCollectionObj();

  let removedRecipe = await recipeObj.removeOne({ _id: id });

  if (removedRecipe.deletedCount === 0) {
    throw `Error : Unable to delete recipe with id : ${id} from database`;
  }

  return true;
}

module.exports = {
  getRecipeById,
  getAllRecipe,
  createRecipe,
  updateRecipe,
  deleteRecipe,
};
