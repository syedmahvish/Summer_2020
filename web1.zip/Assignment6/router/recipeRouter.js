const express = require("express");
const router = express.Router();
const recipeData = require("../data");
const recipeDataObj = recipeData.recipe;

router.get("/recipes", async (req, res) => {
  try {
    let allRecipes = await recipeDataObj.getAllRecipe();
    res.json(allRecipes);
  } catch (error) {
    res.status(404).json({ error: "Recipes not found" });
  }
});

router.get("/recipes/:id", async (req, res) => {
  if (!req.params.id) {
    res.status(404).json({ error: "Recipe Id missing" });
    return;
  }

  try {
    let recipe = await recipeDataObj.getRecipeById(req.params.id);
    res.json(recipe);
  } catch (error) {
    res.status(404).json({ error: "Recipe not found" });
  }
});

router.post("/recipes", async (req, res) => {
  if (
    !req.body ||
    !req.body.title ||
    !req.body.ingredients ||
    !req.body.steps
  ) {
    res.status(404).json({ error: "Must supply all fields." });
    return;
  }

  let recipeParamBody = req.body;
  try {
    let newRecipe = await recipeDataObj.createRecipe(
      recipeParamBody.title,
      recipeParamBody.ingredients,
      recipeParamBody.steps
    );
    res.json(newRecipe);
  } catch (error) {
    res.status(404).json({ error: "Cannot add new Recipe" });
  }
});

router.put("/recipes/:id", async (req, res) => {
  if (
    !req.params.id ||
    !req.body ||
    !req.body.title ||
    !req.body.ingredients ||
    !req.body.steps
  ) {
    res.status(404).json({ error: "Must supply all fields." });
    return;
  }

  let recipeParamBody = req.body;

  try {
    await recipeDataObj.getRecipeById(req.params.id);
  } catch (error) {
    res.status(404).json({ error: "Cannot update Recipe." });
  }

  try {
    let updateRecipe = await recipeDataObj.updateRecipe(
      req.params.id,
      recipeParamBody.title,
      recipeParamBody.ingredients,
      recipeParamBody.steps
    );
    res.json(updateRecipe);
  } catch (error) {
    res.status(404).json({ error: "Cannot update Recipe." });
  }
});

router.patch("/recipes/:id", async (req, res) => {
  if (!req.params.id || !req.body || Object.keys(req.body).length === 0) {
    res.status(404).json({
      error: "Must provide atleast one field in request body.",
    });
    return;
  }

  let recipeBody = req.body;
  let oldRecipe = {};
  try {
    oldRecipe = await recipeDataObj.getRecipeById(req.params.id);

    if (req.body.title && req.body.title != oldRecipe.title) {
      oldRecipe.title = req.body.title;
    }

    if (req.body.ingredients && req.body.ingredients != oldRecipe.ingredients) {
      oldRecipe.ingredients = req.body.ingredients;
    }

    if (req.body.steps && req.body.steps != oldRecipe.steps) {
      oldRecipe.steps = req.body.steps;
    }
  } catch (error) {
    res.status(404).json({ error: "Cannot update Recipe." });
  }

  try {
    let updateRecipe = await recipeDataObj.updateRecipe(
      req.params.id,
      oldRecipe.title,
      oldRecipe.ingredients,
      oldRecipe.steps
    );
    res.json(updateRecipe);
  } catch (error) {
    res.status(404).json({ error: "Cannot update Recipe." });
  }
});

router.delete("/recipes/:id", async (req, res) => {
  if (!req.params.id) {
    res.status(404).json({ error: "Must supply Recipe Id." });
    return;
  }

  try {
    await recipeDataObj.getRecipeById(req.params.id);
  } catch (error) {
    res.status(404).json({ error: "Cannot delete Recipe." });
    return;
  }

  try {
    await recipeDataObj.deleteRecipe(req.params.id);
    res.sendStatus(200);
  } catch (error) {
    res.status(404).json({ error: "Cannot delete Recipe." });
  }
});

module.exports = router;
