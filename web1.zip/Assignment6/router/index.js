const recipeRoutes = require("./recipeRouter");

const constructorMethod = (app) => {
  app.use("/", recipeRoutes);

  app.use("*", (req, res) => {
    res.sendStatus(404);
  });
};

module.exports = constructorMethod;
