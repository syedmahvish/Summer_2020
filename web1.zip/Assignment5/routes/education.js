const express = require("express");
const educationRoute = express.Router();

const myEductaion = [
  {
    schoolName: "Vishwakarma Institute of technology, Pune, India",
    degree: "B.Tech in Computer Science",
    favoriteClass: "Final Year",
    favoriteMemory: "A trip to hill station with classmates.",
  },
  {
    schoolName: "Puranmal Lahoti Government polyechnic, Latur, India",
    degree: "Diploma in Computer Science",
    favoriteClass: "Final Year",
    favoriteMemory: "Gathering Event",
  },
  {
    schoolName: "Adarsha Vidyalaya",
    degree: "Secondary School Certification",
    favoriteClass: "Science and Maths",
    favoriteMemory: "The historic play practice session and farewell",
  },
];

educationRoute.get("/", async (req, res) => {
  try {
    await res.json(myEductaion);
  } catch (error) {
    res.status(400).json({ message: "Page not found" });
  }
});

educationRoute.get("*", async (req, res) => {
  res.status(500).send();
});

module.exports = educationRoute;
