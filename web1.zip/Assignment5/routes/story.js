const express = require("express");
const storyRoute = express.Router();

const myStory = {
  storyTitle: "A Journey to New York",
  story:
    "New york a dream city for many people.\nAfter completing bacherole in Computer Science, decided to pursue masters.So what better than New york state.\nWith all dreams and hope Landed in city of dream.",
};

storyRoute.get("/", async (req, res) => {
  try {
    await res.json(myStory);
  } catch (error) {
    res.status(400).json({ message: "Story Page not found" });
  }
});

storyRoute.get("*", async (res, req) => {
  res.status(500).send();
});

module.exports = storyRoute;
