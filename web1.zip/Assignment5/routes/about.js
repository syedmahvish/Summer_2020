const express = require("express");
const aboutRoute = express.Router();

const aboutMyself = {
  name: "Syed Mahvish",
  cwid: "10456845",
  biography:
    "Myself Syed Mahvish from India. I born and brought up in Mumbai City.Then moved to another city Pune to complete bachelor's in Computer Science.I am in USA since one year.I love liberate culture of states.\nI am passionate about coding and learning new coding languages.Whenever I am bored with studies I do social media surfing.My favourite thing is to do shopping or design dress.",
  favoriteShows: ["Office", "Patallok"],
  hobbies: [
    "Shopping",
    "Travel",
    "Internet surfing",
    "Dress design",
    "Home decor",
  ],
};

aboutRoute.get("/", async (req, res) => {
  try {
    await res.json(aboutMyself);
  } catch (error) {
    res.status(400).json({ message: "About Page not found" });
  }
});

aboutRoute.get("*", async (req, res) => {
  res.status(500).send();
});

module.exports = aboutRoute;
