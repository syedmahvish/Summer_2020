const routerServer = require("./palindromeServer");

const constructorMethod = (app) => {
  app.use("/", routerServer);

  app.use("*", (req, res) => {
    res.status(400).render("error", {
      errors: ["Invalid url"],
      hasErrors: true,
      title: "Errors!!",
    });
    return;
  });
};

module.exports = constructorMethod;
