const express = require("express");
const router = express.Router();

router.get("/", async (req, res) => {
  res.render("input", { title: "Palindrome Checker" });
});

module.exports = router;
