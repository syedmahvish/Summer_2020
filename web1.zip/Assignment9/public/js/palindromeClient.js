let formId = document.getElementById("form-id");
let textAreaID = document.getElementById("input-id");
let orderListId = document.getElementById("attempts");
let div = document.getElementById("div-id");

function checkPalindrome(text) {
  let temp = "";
  text = text.toLowerCase();

  for (let element of text) {
    if (element.match(/^[a-z0-9]+$/)) {
      temp = temp + element;
    }
  }

  let reverseTemp = temp.split("").reverse().join("");

  if (temp === reverseTemp) {
    return true;
  }
  return false;
}

if (formId) {
  formId.addEventListener("submit", (event) => {
    event.preventDefault();

    if (textAreaID.value) {
      div.hidden = true;
      let isPalindrome = checkPalindrome(textAreaID.value);
      let list = document.createElement("li");
      if (isPalindrome) {
        list.className = "is-palindrome";
      } else {
        list.className = "not-palindrome";
      }

      list.innerHTML = textAreaID.value;
      orderListId.appendChild(list);

      textAreaID.value = "";
      textAreaID.focus();
    } else {
      div.hidden = false;
      textAreaID.focus();
    }
  });
}
