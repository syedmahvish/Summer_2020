const questionOne = function questionOne(arr) {
  let sum = 0;
  arr.forEach((value) => {
    sum = sum + value * value;
  });
  return sum;
};

const questionTwo = function questionTwo(num) {
  if (num < 1) return 0;
  if (num >= 1 && num <= 2) return 1;
  return questionTwo(num - 1) + questionTwo(num - 2);
};

const questionThree = function questionThree(text) {
  let vowelCount = 0;
  for (let letter of text) {
    if (
      letter === "a" ||
      letter === "A" ||
      letter === "e" ||
      letter === "E" ||
      letter === "i" ||
      letter === "I" ||
      letter === "o" ||
      letter === "O" ||
      letter === "u" ||
      letter === "U"
    ) {
      vowelCount++;
    }
  }
  return vowelCount;
};

const questionFour = function questionFour(num) {
  if (num < 0) return NaN;
  if (num >= 0 && num <= 1) return 1;
  return num * questionFour(num - 1);
};

module.exports = {
  firstName: "Mahvish",
  lastName: "Syed",
  studentId: "10456845",
  questionOne,
  questionTwo,
  questionThree,
  questionFour,
};
