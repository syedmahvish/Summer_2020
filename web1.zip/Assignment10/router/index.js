const routerServer = require("./login");

const constructorMethod = (app) => {
  app.use("/", routerServer);
  app.use("*", (req, res) => {
    res
      .status(400)
      .render("errors", { errors: ["Invalid url"], hasError: true });
    return;
  });
};

module.exports = constructorMethod;
