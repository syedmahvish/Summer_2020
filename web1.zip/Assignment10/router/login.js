const express = require("express");
const router = express.Router();
const userData = require("../user");
const bcrypt = require("bcrypt");

router.get("/", authenticateUser, log, async (req, res, next) => {
  res.redirect("/private");
});

router.get("/login", log, async (req, res) => {
  if (req.session.user) {
    res.redirect("/private");
  } else {
    res.render("login");
  }
});

router.get("/private", authenticateUser, log, async (req, res, next) => {
  let username = req.session.user;
  let user = userData.getUser(username);
  res.render("private", {
    username: user.username,
    firstName: user.firstName,
    lastName: user.lastName,
    profession: user.profession,
    bio: user.bio,
    id: user.id,
  });
});

router.get("/logout", log, async (req, res, next) => {
  if (req.session.user) {
    console.log(`${req.session.user} is successfully Logged out.`);
  } else {
    console.log(`User is successfully Logged out.`);
  }
  req.session.destroy();
  res.clearCookie("AuthCookie");
  res.render("logout");
});

router.post("/login", log, async (req, res, next) => {
  let username = "";
  let password = "";

  //check if username and password is empty or not.
  if (req.body) {
    username = req.body["username"];
    password = req.body["password"];
  }

  if (!username && !password) {
    res.status(400).render("login", {
      usernameMessage: "Please enter valid username",
      passwordMessage: "Please enter valid password",
    });
    return;
  }

  if (!username) {
    res.status(400).render("login", {
      usernameMessage: "Please enter valid username",
    });
    return;
  }

  if (!password) {
    res.status(400).render("login", {
      username: username,
      passwordMessage: "Please enter valid password",
    });
    return;
  }

  //validate credentials for given username
  let user = userData.getUser(username);
  if (user) {
    let validUsername = user.username;
    let isValidPassword = await bcrypt.compareSync(
      password,
      user.hashedPassword
    );

    if (validUsername != username && !isValidPassword) {
      res.status(400).render("login", {
        usernameMessage: "Incorrect username",
        passwordMessage: "Incorrect password",
      });
      return;
    }

    if (validUsername === username && !isValidPassword) {
      res.status(400).render("login", {
        username: username,
        passwordMessage: "Incorrect password",
      });
      return;
    }
    req.session.user = username;
    res.redirect("/private");
  }

  if (!req.session.user) {
    res.status(400).render("login", {
      usernameMessage: "Please enter valid username",
      passwordMessage: "Please enter valid password",
    });
    return;
  }
});

async function authenticateUser(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    if (req.originalUrl === "/private") {
      res.status(403).render("errors", {
        errors: ["Errors : User is not logged in. Forbidden user error : 403"],
        hasError: true,
        tittle: "Errors",
      });
    } else {
      res.redirect("/login");
    }
  }
}

async function log(req, res, next) {
  console.log(`Current Timestamp: ${new Date().toUTCString()}`);
  console.log(`Request Method: ${req.method}`);
  console.log(`Request url: ${req.originalUrl}`);
  if (req.session.user) {
    console.log(`Authenticate User`);
  } else {
    console.log(`Non authenticate User`);
  }
  console.log("---------------------------------------------------");
  next();
}

module.exports = router;
