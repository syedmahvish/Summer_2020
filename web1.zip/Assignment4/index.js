const animals = require("./data/animals");
const connection = require("./DBConnection");

async function main() {
  let sasha = "";
  let lucy = "";
  let duke = "";
  try {
    // Create an animal named Sasha with the type of Dog
    sasha = await animals.create("Sasha", "Dog");

    // Log the newly created animal
    console.log("------Newly created animals------");
    console.log(sasha);
  } catch (error) {
    console.log("Error found :" + error);
  }

  try {
    // Create an animal named Lucy, with the type of Dog
    lucy = await animals.create("Lucy", "Dog");
  } catch (error) {
    console.log("Error found :" + error);
  }

  try {
    // Query all animals, and log them all
    let allAnimals = await animals.getAll();
    console.log("------All Animals------");
    console.log(allAnimals);
  } catch (error) {
    console.log("Error found :" + error);
  }

  try {
    // Create an animal named Duke, with a type of Walrus
    duke = await animals.create("Duke", "Walrus");

    // Log the newly created Duke
    console.log("------Newly created animals------");
    console.log(duke);
  } catch (error) {
    console.log("Error found :" + error);
  }

  try {
    // Rename Sasha to Sashita
    const renameSasha = await animals.rename(sasha._id, "Sashita");

    // Log the newly named Sashita
    console.log("------Rename animals------");
    console.log(renameSasha);
  } catch (error) {
    console.log("Error found :" + error);
  }

  try {
    // Remove Lucy
    const removeLucy = await animals.remove(lucy._id);
    console.log("------removed Animals------");
    console.log(removeLucy);
  } catch (error) {
    console.log("Error found :" + error);
  }

  try {
    // Query all animals, and log them all
    allAnimals = await animals.getAll();
    console.log("------All Animals------");
    console.log(allAnimals);
  } catch (error) {
    console.log("Error found :" + error);
  }

  const db = await connection();
  await db.serverConfig.close();
}

main();
