const collections = require("../Collections.js");
const animals = collections.animalscollection;
const handleObj = require("mongodb").ObjectID;

async function create(name, animalType) {
  name = getValidString(name, "animal name");
  animalType = getValidString(animalType, "animal type");

  const animalCollectionObj = await animals();

  const animalSchema = {
    name: name,
    animalType: animalType,
  };

  const addAnimal = await animalCollectionObj.insertOne(animalSchema);

  if (addAnimal.insertedCount === 0) {
    throw "Error : Cannot add animal into database";
  }
  let animalId = addAnimal.insertedId;

  let animalResult = await get(animalId);

  return animalResult;
}

async function getAll() {
  const animalCollectionObj = await animals();

  const animalResult = await animalCollectionObj.find({}).toArray();
  if (animalResult === null) {
    throw "Error : Cannot find animal into database";
  }

  return animalResult;
}

async function get(id) {
  let animalID = getValidId(id);
  const animalCollectionObj = await animals();

  const animalResult = await animalCollectionObj.findOne({ _id: animalID });
  if (animalResult === null) {
    throw `Error : Cannot find animal with given id : ${id} into database`;
  }

  return animalResult;
}

async function remove(id) {
  let animalID = getValidId(id);
  const animalCollectionObj = await animals();

  const returnAnimalResult = await animalCollectionObj.findOne({
    _id: animalID,
  });
  const deleteAnimal = await animalCollectionObj.deleteOne({ _id: animalID });
  if (deleteAnimal.deletedCount === 0 || returnAnimalResult === null) {
    throw `Error : Cannot delete animal with given id : ${id} into database`;
  }
  return returnAnimalResult;
}

async function rename(id, newName) {
  let animalID = getValidId(id);
  newName = getValidString(newName, "animal name");

  const newAnimalSchema = {
    name: newName,
  };

  const animalCollectionObj = await animals();

  const updateAnimalName = await animalCollectionObj.updateOne(
    { _id: animalID },
    { $set: newAnimalSchema }
  );

  if (updateAnimalName.modifiedCount === 0) {
    throw `Error : Cannot rename given animal of id : ${id} into database`;
  }

  return this.get(animalID);
}

function getValidId(id) {
  if (!id) {
    throw "Given animal id is invalid";
  }

  if (typeof id != "object" && typeof id != "string") {
    throw "Provide animal id of type object or string ";
  }

  let animalID = id;

  if (typeof id === "string") {
    if (!handleObj.isValid(id)) {
      throw "Given animal id is invalid string ID";
    }
    animalID = handleObj.createFromHexString(id);
  }

  return animalID;
}

function getValidString(str, variableName) {
  if (!str) {
    throw `Provided ${variableName} is invalid`;
  }

  if (typeof str != "string") {
    throw `Given ${str} is not a string`;
  }

  if (str.trim().length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return str;
}

module.exports = { create, getAll, get, remove, rename };
