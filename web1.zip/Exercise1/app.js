let dict = require("./dictionary");

console.log("--------------Test case that will pass--------------");
try {
  console.log(dict.lookupDefinition("programming"));
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}

try {
  console.log(dict.lookupDefinition("adjudicate"));
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}

try {
  console.log(
    dict.getWord("The action or process of writing computer programs.")
  );
} catch (e) {
  console.log("Error in getWord : " + e);
}

try {
  console.log(dict.getWord("To act as a detective : search for information"));
} catch (e) {
  console.log("Error in getWord : " + e);
}

console.log("----------Test case that will Fail-------------");
try {
  console.log(dict.lookupDefinition("gibberish"));
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}
try {
  console.log(
    dict.lookupDefinition("To act as a detective : search for information")
  );
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}
try {
  console.log(dict.lookupDefinition(1234));
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}
try {
  console.log(dict.lookupDefinition(null));
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}
try {
  console.log(dict.lookupDefinition(undefined));
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}
try {
  console.log(dict.lookupDefinition("  "));
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}
try {
  console.log(dict.lookupDefinition(""));
} catch (e) {
  console.log("Error in lookupDefinition : " + e);
}

try {
  console.log(dict.getWord("this defination does not exsisit"));
} catch (e) {
  console.log("Error in getWord : " + e);
}
try {
  console.log(dict.getWord(null));
} catch (e) {
  console.log("Error in getWord : " + e);
}
try {
  console.log(dict.getWord(undefined));
} catch (e) {
  console.log("Error in getWord : " + e);
}
try {
  console.log(dict.getWord(4325345));
} catch (e) {
  console.log("Error in getWord : " + e);
}
try {
  console.log(dict.getWord(" "));
} catch (e) {
  console.log("Error in getWord : " + e);
}
