const words = {
  programming: "The action or process of writing computer programs.",
  charisma:
    "A personal magic of leadership arousing special popular loyalty or enthusiasm for a public figure (such as a political leader)",
  sleuth: "To act as a detective : search for information",
  foray: "A sudden or irregular invasion or attack for war or spoils : raid",
  adjudicate:
    "to make an official decision about who is right in (a dispute) : to settle judicially",
};

function checkInput(input) {
  if (input === null) {
    throw "Input is null";
  }

  if (input === undefined) {
    throw "Input is undefined";
  }

  if (typeof input != "string") {
    throw `${input} is not a String`;
  }

  if (input === "" || input.length === 0) {
    throw "Given string is empty";
  }

  return input;
}

function lookupDefinition(inputVal) {
  checkInput(inputVal);
  if (words[inputVal] === undefined) {
    throw "Given word does not found in dictionary";
  }
  return words[inputVal];
}

function getWord(inputVal) {
  checkInput(inputVal);
  let key = getKey(inputVal);
  if (key === undefined) {
    throw "Given defination does not found in dictionary";
  }

  return key;
}

function getKey(inputVal) {
  for (let key of Object.keys(words)) {
    if (words[key] === inputVal) {
      return key;
    }
  }
  return undefined;
}

module.exports = { lookupDefinition, getWord };
