const bluebird = require("bluebird");
const Promise = bluebird.Promise;
const file = bluebird.promisifyAll(require("fs"));

const fileData = require("./fileData");
const textMetrics = require("./textMetrics");

let saveExtension = ".result.json";
let fileNameArray = ["chapter1.txt", "chapter2.txt", "chapter3.txt"];

async function checkFileName(fileName) {
  if (fileName === null) {
    throw "Error in fileName : Given fileName is null.";
  }
  if (fileName === undefined) {
    throw "Error in fileName : Given fileName is undefined.";
  }
  if (typeof fileName != "string") {
    throw "Error in fileName : Given fileName is not valid filename.";
  }

  if (fileName === "") {
    throw "Error in fileName : Given fileName is empty.";
  }
  return fileName;
}

async function readFile(fileName) {
  let readFilePath = await checkFileName(fileName);
  let writeFilePath = readFilePath.replace(".txt", saveExtension);

  if (file.existsSync(writeFilePath)) {
    let jsonObject = await fileData.getFileAsJSON(writeFilePath);
    console.log(jsonObject);
  } else {
    let text = await fileData.getFileAsString(readFilePath);
    let jsonObject = textMetrics.createMetrics(text);
    await fileData.saveJSONToFile(writeFilePath, jsonObject);
    console.log(jsonObject);
  }
}
async function main() {
  try {
    for (let index = 0; index < fileNameArray.length; index++) {
      await readFile("./" + fileNameArray[index]);
    }
  } catch (err) {
    console.log("Error while reading or writing file : " + err);
  }
}

main();
