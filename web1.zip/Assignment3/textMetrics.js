function createMetrics(text) {
  if (text === null || text === undefined) {
    throw "Given text is null or undefied";
  }

  if (typeof text != "string") {
    throw "Given text is not a string";
  }

  if (text === "") {
    throw "Given text is empty";
  }

  text = text.toLowerCase();

  let uniqueWordSet = new Set();
  let wordOccurenceMap = {};

  let metric = {
    totalLetters: 0,
    totalNonLetters: 0,
    totalVowels: 0,
    totalConsonants: 0,
    totalWords: 0,
    uniqueWords: 0,
    longWords: 0,
    averageWordLength: 0,
    wordOccurrences: wordOccurenceMap,
  };

  let temp = "";

  for (let letter of text) {
    if (letter.match(/^[a-z]+$/)) {
      temp = temp + letter;
      metric.totalLetters++;
      if (
        letter === "a" ||
        letter === "e" ||
        letter === "i" ||
        letter === "o" ||
        letter === "u "
      ) {
        metric.totalVowels++;
      } else {
        metric.totalConsonants++;
      }
    } else {
      metric.totalNonLetters++;
      if (temp != "") {
        metric.totalWords++;
        uniqueWordSet.add(temp);

        if (temp.length >= 6) {
          metric.longWords++;
        }

        if (temp in wordOccurenceMap) {
          wordOccurenceMap[temp]++;
        } else {
          wordOccurenceMap[temp] = 1;
        }
      }
      temp = "";
    }
  }
  metric.uniqueWords = uniqueWordSet.size;
  metric.wordOccurrences = wordOccurenceMap;
  if (metric.totalLetters === 0 || metric.totalWords === 0) {
    metric.averageWordLength = 0;
  } else {
    metric.averageWordLength = metric.totalLetters / metric.totalWords;
  }

  return metric;
}

module.exports = { createMetrics };
