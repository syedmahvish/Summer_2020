const bluebird = require("bluebird");
const Promise = bluebird.Promise;
const file = bluebird.promisifyAll(require("fs"));

async function checkValidString(path, variableName) {
  if (path === null) {
    throw `Error in ${variableName} : Given ${variableName} is null.`;
  }
  if (path === undefined) {
    throw `Error in ${variableName} : Given ${variableName} is undefined.`;
  }
  if (typeof path != "string") {
    throw `Error in ${variableName} : Given ${variableName} is not valid filename.`;
  }

  if (path === "") {
    throw `Error in ${variableName} : Given ${variableName} is empty.`;
  }
  return path;
}

async function checkValidObject(obj) {
  if (obj === null || obj === undefined) {
    throw "Error in JsonObject : Given object is null or undefined";
  }

  if (typeof obj != "object") {
    throw "Error in JsonObject : Given data is not an object";
  }

  return obj;
}

async function getFileAsString(path) {
  let fileName = await checkValidString(path, "filePath");
  let stringFileData = await file.readFileAsync(fileName, "utf-8");
  let validStringData = await checkValidString(stringFileData, "fileText");
  return validStringData;
}

async function getFileAsJSON(path) {
  let validStringData = await getFileAsString(path);
  let stringJSON = JSON.parse(validStringData);
  return stringJSON;
}

async function saveStringToFile(path, text) {
  let fileName = await checkValidString(path, "filePath");
  let validText = await checkValidString(text, "fileText");
  let saveFile = await file.writeFileAsync(fileName, validText);
  return saveFile;
}

async function saveJSONToFile(path, obj) {
  let validObj = await checkValidObject(obj);
  let text = JSON.stringify(validObj);
  let saveFile = await saveStringToFile(path, text);
  return saveFile;
}

module.exports = {
  getFileAsJSON,
  getFileAsString,
  saveJSONToFile,
  saveStringToFile,
};
