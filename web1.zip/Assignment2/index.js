const geometry = require("./geometry");
const utilities = require("./utilities");

console.log("-----Volume of Rectangular Prism--------");
//proper argument
try {
  console.log(geometry.volumeOfRectangularPrism(4, 5, 6));
} catch (e) {
  console.log("Error: Volume of Rectangular Prism : " + e);
}

try {
  console.log(geometry.volumeOfRectangularPrism(undefined, 5, 6));
} catch (e) {
  console.log("Error: Volume of Rectangular Prism : " + e);
}

//with string and missing argument
try {
  console.log(geometry.volumeOfRectangularPrism("string", 4));
} catch (e) {
  console.log("Error: Volume of Rectangular Prism : " + e);
}

//with decimal argument
try {
  console.log(geometry.volumeOfRectangularPrism(4.5, 64.5, 9.3));
} catch (e) {
  console.log("Error: Volume of Rectangular Prism : " + e);
}

//with lower and higher bound argument
try {
  console.log(geometry.volumeOfRectangularPrism(Infinity, 3, 78));
} catch (e) {
  console.log("Error: Volume of Rectangular Prism : " + e);
}

console.log("-----Surface area of Rectangular Prism--------");
//proper argument
try {
  console.log(geometry.surfaceAreaOfRectangularPrism(4, 5, 6));
} catch (e) {
  console.log("Error: Surface area of Rectangular Prism : " + e);
}

//with string and missing argument
try {
  console.log(geometry.surfaceAreaOfRectangularPrism("string", 4));
} catch (e) {
  console.log("Error: Surface area of Rectangular Prism : " + e);
}

//with decimal argument
try {
  console.log(geometry.surfaceAreaOfRectangularPrism(4.5, 64.5, 9.3));
} catch (e) {
  console.log("Error: Surface area of Rectangular Prism : " + e);
}

//with lower and higher bound argument
try {
  console.log(geometry.surfaceAreaOfRectangularPrism(3, 0, 0));
} catch (e) {
  console.log("Error: Surface area of Rectangular Prism : " + e);
}

try {
  console.log(geometry.surfaceAreaOfRectangularPrism(Infinity, 3, 78));
} catch (e) {
  console.log("Error: Surface area of Rectangular Prism : " + e);
}

console.log("-----Volume of Sphere--------");
//proper argument
try {
  console.log(geometry.volumeOfSphere(4));
} catch (e) {
  console.log("Error: Volume of Sphere : " + e);
}

//with string and missing argument
try {
  console.log(geometry.volumeOfSphere("string"));
} catch (e) {
  console.log("Error: Volume of Sphere : " + e);
}

//with missing argument
try {
  console.log(geometry.volumeOfSphere());
} catch (e) {
  console.log("Error: Volume of Sphere : " + e);
}

//with negative argument
try {
  console.log(geometry.volumeOfSphere(-98));
} catch (e) {
  console.log("Error: Volume of Sphere : " + e);
}

//with decimal argument
try {
  console.log(geometry.volumeOfSphere(45.6));
} catch (e) {
  console.log("Error: Volume of Sphere : " + e);
}

//with lower and higher bound argument
try {
  console.log(geometry.volumeOfSphere(0));
} catch (e) {
  console.log("Error: Volume of Sphere : " + e);
}
try {
  console.log(geometry.volumeOfSphere(Infinity));
} catch (e) {
  console.log("Error: Volume of Sphere : " + e);
}

console.log("-----Surface area of Sphere--------");
//proper argument
try {
  console.log(geometry.surfaceAreaOfSphere(4));
} catch (e) {
  console.log("Error: Surface area of Sphere : " + e);
}

//with string and missing argument
try {
  console.log(geometry.surfaceAreaOfSphere("string"));
} catch (e) {
  console.log("Error: Surface area of Sphere : " + e);
}

//with missing argument
try {
  console.log(geometry.surfaceAreaOfSphere());
} catch (e) {
  console.log("Error: Surface area of Sphere : " + e);
}

//with negative argument
try {
  console.log(geometry.surfaceAreaOfSphere(-98));
} catch (e) {
  console.log("Error: Surface area of Sphere : " + e);
}

//with decimal argument
try {
  console.log(geometry.surfaceAreaOfSphere(45.6));
} catch (e) {
  console.log("Error: Surface area of Sphere : " + e);
}

//with lower and higher bound argument
try {
  console.log(geometry.surfaceAreaOfSphere(0));
} catch (e) {
  console.log("Error: Surface area of Sphere : " + e);
}
try {
  console.log(geometry.surfaceAreaOfSphere(Infinity));
} catch (e) {
  console.log("Error: Surface area of Sphere : " + e);
}

//Deep Equality Check
console.log("-----Deep Equality check for objects --------");
try {
  let first = { a: 2, b: 3 };
  let second = { a: 2, b: 4 };
  let third = { a: 2, b: 3 };
  console.log(utilities.deepEquality(first, second)); // false
  console.log(utilities.deepEquality(first, third)); // true
  second = { b: 2, a: 4 };
  third = { a: 4, b: 2 };
  console.log(utilities.deepEquality(second, third)); // true
  second = { b: 32, a: 4 };
  third = { a: 4, b: 2 };
  console.log(utilities.deepEquality(second, third)); // false
} catch (e) {
  console.log("Error : Deep Equality check for objects :" + e);
}

//unequal length
try {
  let first = { a: 2, b: 3, c: 1 };
  let second = { a: 2, b: 4 };
  console.log(utilities.deepEquality(first, second)); // false
} catch (e) {
  console.log("Error : Deep Equality check for objects :" + e);
}

//different keys
try {
  let first = { a: 2, b: 3, c: 1 };
  let second = { a: 2, b: 3, d: 1 };
  console.log(utilities.deepEquality(first, second)); // false
} catch (e) {
  console.log("Error : Deep Equality check for objects :" + e);
}

//undefined objects
try {
  let second = { a: 2, b: 4 };
  console.log(utilities.deepEquality(second));
} catch (e) {
  console.log("Error : Deep Equality check for objects :" + e);
}

//passing a string as argument
try {
  let second = { a: 2, b: 4 };
  console.log(utilities.deepEquality("Hello ", second));
} catch (e) {
  console.log("Error : Deep Equality check for objects :" + e);
}

//Empty argument
try {
  console.log(utilities.deepEquality());
} catch (e) {
  console.log("Error : Deep Equality check for objects :" + e);
}
///null argument
try {
  console.log(utilities.deepEquality(null, null));
} catch (e) {
  console.log("Error : Deep Equality check for objects :" + e);
}

//Count Unique elements in array
console.log("-----Count Unique elements in array --------");
try {
  console.log(utilities.uniqueElements(["a", "a", "b", "a", "b", "c"]));
} catch (e) {
  console.log("Error : Count Unique elements in array :" + e);
}

//number, special character and string
try {
  console.log(
    utilities.uniqueElements([
      "34",
      "hello",
      "hello",
      "-89",
      "78",
      "-89",
      ",",
      "h",
      "e",
      "e",
    ])
  );
} catch (e) {
  console.log("Error : Count Unique elements in array :" + e);
}

//empty array
try {
  console.log(utilities.uniqueElements([]));
} catch (e) {
  console.log("Error : Count Unique elements in array :" + e);
}

//String argument instead of array
try {
  console.log(utilities.uniqueElements("This is to test"));
} catch (e) {
  console.log("Error : Count Unique elements in array :" + e);
}

//No argument
try {
  console.log(utilities.uniqueElements());
} catch (e) {
  console.log("Error : Count Unique elements in array :" + e);
}

try {
  console.log(utilities.uniqueElements(undefined));
} catch (e) {
  console.log("Error : Count Unique elements in array :" + e);
}

try {
  console.log(utilities.uniqueElements(null));
} catch (e) {
  console.log("Error : Count Unique elements in array :" + e);
}

try {
  console.log(utilities.uniqueElements(""));
} catch (e) {
  console.log("Error : Count Unique elements in array :" + e);
}

//count Of Each Character In String
console.log("-----Count Of Each Character In String --------");
try {
  console.log(
    utilities.countOfEachCharacterInString("Hello, the pie is in the oven")
  );
} catch (e) {
  console.log("Error : Count Of Each Character In String :" + e);
}

//special characters and numbers.
try {
  console.log(
    utilities.countOfEachCharacterInString(
      "   He is a boy\n He is 2 yrs old!!!\nHe lives in  a %%%%small town^&#%#$%"
    )
  );
} catch (e) {
  console.log("Error : Count Of Each Character In String :" + e);
}

//only whitespace String
try {
  console.log(utilities.countOfEachCharacterInString(" "));
} catch (e) {
  console.log("Error : Count Of Each Character In String :" + e);
}

//Passing an array instead of string
try {
  console.log(
    utilities.countOfEachCharacterInString([
      "He is a boy. He is 2 yrs old!!!",
      "2",
      "3",
    ])
  );
} catch (e) {
  console.log("Error : Count Of Each Character In String :" + e);
}

//Passing a Number instead of string
try {
  console.log(utilities.countOfEachCharacterInString(2));
} catch (e) {
  console.log("Error : Count Of Each Character In String :" + e);
}

//No argument
try {
  console.log(utilities.countOfEachCharacterInString(""));
} catch (e) {
  console.log("Error : Count Of Each Character In String :" + e);
}

try {
  console.log(utilities.countOfEachCharacterInString(null));
} catch (e) {
  console.log("Error : Count Of Each Character In String :" + e);
}

try {
  console.log(utilities.countOfEachCharacterInString(undefined));
} catch (e) {
  console.log("Error : Count Of Each Character In String :" + e);
}
