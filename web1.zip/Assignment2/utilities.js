function deepEquality(obj1, obj2) {
  if (obj1 === undefined || obj2 === undefined) {
    throw "Either obj1 or obj2 or both are undefined";
  }
  if (obj1 === null || obj2 === null) {
    throw "Either obj1 or obj2 or both are null";
  }

  if (typeof obj1 != "object" || typeof obj2 != "object") {
    throw `"${obj1} || ${obj2}" is not an object`;
  }

  if (Object.keys(obj1).length != Object.keys(obj2).length) return false;

  let isEqualFlag = false;

  for (let key of Object.keys(obj1)) {
    if (obj2.hasOwnProperty(key) == true) {
      if (obj2[key] === obj1[key]) {
        isEqualFlag = true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  return isEqualFlag;
}

function uniqueElements(arr) {
  if (arr === undefined) {
    throw "Array is undefined";
  }

  if (arr === null) {
    throw "Array is null";
  }

  if (!Array.isArray(arr)) {
    throw `"${arr}" is not an array`;
  }

  if (arr.length === 0) {
    throw "Array is empty";
  }

  let uniqueElementsArray = [];
  arr.forEach((element) => {
    if (!uniqueElementsArray.includes(element)) {
      uniqueElementsArray.push(element);
    }
  });
  return uniqueElementsArray.length;
}

function countOfEachCharacterInString(str) {
  if (str === undefined) {
    throw "String is undefined";
  }

  if (str === null) {
    throw "String is null";
  }

  if (typeof str != "string") {
    throw `"${str}" is not a String`;
  }

  if (str === "") {
    throw "Given string is empty";
  }

  let uniqueCharMap = {};

  for (let letter of str) {
    if (letter in uniqueCharMap) {
      uniqueCharMap[letter]++;
    } else {
      uniqueCharMap[letter] = 1;
    }
  }
  return uniqueCharMap;
}

module.exports = { uniqueElements, countOfEachCharacterInString, deepEquality };
