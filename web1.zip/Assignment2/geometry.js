function checkIsNumber(value, valueName) {
  if (value === undefined || value === Infinity) {
    throw `${valueName || "provided variable"} cannot be undefined`;
  }

  if (value === null) {
    throw `${valueName || "provided variable"} cannot be null`;
  }

  if (typeof value != "number") {
    throw `${valueName || "provided variable"} is not a number`;
  }

  if (value <= 0) {
    throw `${valueName} is a zero or negative number which is invalid`;
  } else {
    return true;
  }
}

function volumeOfRectangularPrism(length, width, height) {
  if (
    checkIsNumber(length, "length") &&
    checkIsNumber(width, "width") &&
    checkIsNumber(height, "height")
  ) {
    return length * width * height;
  }
}

function surfaceAreaOfRectangularPrism(length, width, height) {
  if (
    checkIsNumber(length, "length") &&
    checkIsNumber(width, "width") &&
    checkIsNumber(height, "height")
  ) {
    return 2 * (width * length + height * length + height * width);
  }
}

function volumeOfSphere(radius) {
  if (checkIsNumber(radius, "radius")) {
    return (4 / 3) * Math.PI * radius * radius * radius;
  }
}

function surfaceAreaOfSphere(radius) {
  if (checkIsNumber(radius, "radius")) {
    return 4 * Math.PI * radius * radius;
  }
}

module.exports = {
  volumeOfRectangularPrism,
  surfaceAreaOfRectangularPrism,
  volumeOfSphere,
  surfaceAreaOfSphere,
};
