const palindromRoute = require("./palindrome");
const path = require("path");

const constructorMethod = (app) => {
  app.use("/", palindromRoute);
  app.use("/result", palindromRoute);

  app.use("*", (req, res) => {
    res.status(400).render("error", {
      errors: ["Invalid url"],
      hasErrors: true,
      title: "Errors!!",
    });
    return;
  });
};

module.exports = constructorMethod;
