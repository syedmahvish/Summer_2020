const express = require("express");
const router = express.Router();
const data = require("../data");
const plaindromeData = data.palindrome;

router.get("/", async (req, res) => {
  res.render("input", { title: "The Best Palindrome Checker in the World!" });
});

router.get("/result", async (req, res) => {
  res.render("result", {
    palindromeText: "You must fill out the form to view results",
    title: "The Palindrome Results!",
  });
});

router.post("/result", async (req, res) => {
  let palindromeText = req.body["text-to-test"];
  let errors = [];

  if (!palindromeText) {
    errors.push("Empty text provided");
  }

  if (errors.length > 0) {
    res.status(400).render("error", {
      errors: errors,
      hasErrors: true,
      title: "Errors!!",
    });
    return;
  }

  try {
    let isPalindrome = await plaindromeData.checkPalindrome(palindromeText);
    let message = "Given text is a Palindrome";
    if (!isPalindrome) {
      message = "Given text is not a Palindrome";
    }
    res.render("result", {
      validPalindrome: isPalindrome,
      palindromeText: palindromeText,
      message: message,
      title: "The Palindrome Results!",
    });
  } catch (e) {
    res.status(500).json({ error: e });
  }
});

module.exports = router;
