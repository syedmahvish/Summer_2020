function checkValidString(text) {
  if (!text) {
    throw `Given ${text} is not valid.`;
  }

  if (typeof text != "string") {
    throw `Given ${text} is not string.`;
  }

  if (text.trim().length === 0) {
    throw `Given ${text} is empty.`;
  }

  return text;
}

async function checkPalindrome(text) {
  text = checkValidString(text);
  let temp = "";
  text = text.toLowerCase();

  for (let element of text) {
    if (element.match(/^[a-z0-9]+$/)) {
      temp = temp + element;
    }
  }

  let reverseTemp = temp.split("").reverse().join("");

  if (temp === reverseTemp) {
    return true;
  }
  return false;
}

module.exports = { checkPalindrome };
