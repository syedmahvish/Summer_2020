const bands = require("./bands");
const connection = require("./DBConnection");

async function main() {
  let band1;
  let band2;
  try {
    band1 = await bands.addBand(
      "Pink flyod",
      ["Roger Waters", "David Gilmour", "Richard Wright", "Nick Mason"],
      1965,
      ["Psychedelic rock", "Classic Rock", "Rock"],
      "Columbia Records"
    );
    console.log("----New band created  1-------");
    console.log(band1);
  } catch (error) {
    console.log("Error occured :" + error);
  }

  try {
    band2 = await bands.addBand(
      "Jammy jam",
      ["Lilly puts", "David Dare", "Dwight schrute"],
      1991,
      ["Indian classic", "Hiphop"],
      "T-Series"
    );
  } catch (error) {
    console.log("Error occured :" + error);
  }

  try {
    const band = await bands.getAllBands();
    console.log("----Get all band-------");
    console.log(band);
  } catch (error) {
    console.log("Error occured :" + error);
  }

  try {
    const band = await bands.removeBand(band1._id);
    console.log("----Removed band-------");
    console.log(band);
  } catch (error) {
    console.log("Error occured :" + error);
  }

  try {
    const band = await bands.getAllBands();
    console.log("----Get all band-------");
    console.log(band);
  } catch (error) {
    console.log("Error occured :" + error);
  }

  try {
    const band = await bands.getBand(band2._id);
    const updatedBand = await bands.updateBand(
      band._id,
      "Jammy jam",
      ["Lilly puts", "David Dare", "Dwight schrute", "Michael scott"],
      1990,
      ["Indian classic", "Hiphop", "Salsa"],
      "T-Series"
    );
    console.log("----Update band-------");
    console.log(updatedBand);
  } catch (error) {
    console.log("Error occured :" + error);
  }

  const db = await connection();
  await db.serverConfig.close();
}

main();
