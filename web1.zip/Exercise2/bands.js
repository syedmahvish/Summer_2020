const collection = require("./Collections");
const bandsCollection = collection.bandsCollection;
const { ObjectId } = require("mongodb");

function checkValidString(str, variableName) {
  if (str === null) {
    throw `Given ${variableName} is null.`;
  }

  if (str === undefined) {
    throw `Given ${variableName} is undefined.`;
  }

  if (typeof str != "string") {
    throw `Given ${variableName} : ${str} is not a string.`;
  }

  if (str.trim().length === 0) {
    throw `Given ${variableName} is empty.`;
  }
  return str;
}

function checkValidNumber(num, variableName) {
  if (num === null) {
    throw `Given ${variableName} is null.`;
  }

  if (num === undefined) {
    throw `Given ${variableName} is undefined.`;
  }

  if (typeof num != "number") {
    throw `Given ${variableName} : ${num} is not a number.`;
  }

  var current_year = new Date().getFullYear();
  if (num < 0 || num.toString().length != 4 || num > current_year) {
    throw `Given ${variableName} : ${num} is invalid.`;
  }

  return num;
}

function checkValidArray(array, variableName) {
  if (array === null) {
    throw `Given ${variableName} is null.`;
  }

  if (array === undefined) {
    throw `Given ${variableName} is undefined.`;
  }

  if (!Array.isArray(array)) {
    throw `Given ${variableName} : ${array} is not a Array.`;
  }

  if (array.length <= 0) {
    throw `Given ${variableName} is empty.`;
  }

  return array;
}

function checkValidId(id) {
  if (!id) {
    throw "Given band id is invalid";
  }

  if (typeof id != "object" && typeof id != "string") {
    throw "Provide band id of type object or string ";
  }

  let animalID = id;

  if (typeof id === "string") {
    if (!ObjectId.isValid(id)) {
      throw "Given band id is invalid string ID";
    }
    animalID = ObjectId.createFromHexString(id);
  }

  return animalID;
}

async function addBand(bandName, bandMembers, yearFormed, genres, recordLabel) {
  bandName = checkValidString(bandName, "Band Name");
  bandMembers = checkValidArray(bandMembers, "Band Members");
  yearFormed = checkValidNumber(yearFormed, "Year Formed");
  genres = checkValidArray(genres, "Genres");
  recordLabel = checkValidString(recordLabel, "Record Label");

  let bandsSchema = {
    bandName: bandName,
    bandMembers: bandMembers,
    yearFormed: yearFormed,
    genres: genres,
    recordLabel: recordLabel,
  };

  const bandCollectObj = await bandsCollection();
  let newRecord = await bandCollectObj.insertOne(bandsSchema);

  if (newRecord.insertedCount === null) {
    throw "Error : unable to add new band into database";
  }

  let bandId = newRecord.insertedId;

  return await getBand(bandId);
}

async function getBand(id) {
  id = checkValidId(id);
  const bandCollectObj = await bandsCollection();
  let record = await bandCollectObj.findOne({ _id: id });
  if (record === null) {
    throw `Error : Unable to find band with id : ${id} into database`;
  }
  return record;
}

async function getAllBands() {
  const bandCollectObj = await bandsCollection();
  let record = await bandCollectObj.find({}).toArray();
  if (record === null) {
    throw `Error : Unable to find band into database`;
  }

  return record;
}

async function updateBand(
  bandId,
  bandName,
  bandMembers,
  yearFormed,
  genres,
  recordLabel
) {
  bandId = checkValidId(bandId);
  bandName = checkValidString(bandName, "Band Name");
  bandMembers = checkValidArray(bandMembers, "Band Members");
  yearFormed = checkValidNumber(yearFormed, "Year Formed");
  genres = checkValidArray(genres, "Genres");
  recordLabel = checkValidString(recordLabel, "Record Label");

  let updateSchema = {
    bandId: bandId,
    bandName: bandName,
    bandMembers: bandMembers,
    yearFormed: yearFormed,
    genres: genres,
    recordLabel: recordLabel,
  };

  const bandCollectObj = await bandsCollection();

  let updateRecord = await bandCollectObj.updateOne(
    { _id: bandId },
    { $set: updateSchema }
  );

  if (updateRecord.modifiedCount === 0) {
    throw `Error : Unable to update band with id : ${bandId} into database`;
  }

  return await this.getBand(bandId);
}

async function removeBand(id) {
  id = checkValidId(id);

  const bandCollectObj = await bandsCollection();

  let removedRecord = await bandCollectObj.deleteOne({ _id: id });

  if (removedRecord.deletedCount === 0) {
    throw `Error : Unable to delete band with id : ${bandId} into database`;
  }

  return true;
}

module.exports = { addBand, getBand, getAllBands, updateBand, removeBand };
