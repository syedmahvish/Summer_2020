const dbConnection = require("../config/mongoConnection");
const data = require("../data");
const bands = data.bands;

const main = async () => {
  const db = await dbConnection();
  await db.dropDatabase();

  let band1 = await bands.addBand(
    "Pink flyod",
    ["Roger Waters", "Richard Wright", "Nick Mason"],
    1965,
    ["Psychedelic rock", "Classic Rock", "Rock"],
    "Columbia Records"
  );

  let band2 = await bands.addBand(
    "Cold Sweat ",
    ["George Clinton", "Rufus"],
    1980,
    ["R&B", "Jazz", "Soul music"],
    "Family Stone"
  );

  let band3 = await bands.addBand(
    "Yadeein",
    ["Abhijeet", "Sonu nigam"],
    2018,
    ["Romantic", "Soul"],
    "T-Series"
  );

  let band4 = await bands.addBand(
    "Imagine",
    ["Paul Simon", "Gloria Gaynor"],
    1970,
    ["Disco/Dance", "Progressive Rock", "Punk", "New Wave"],
    "Columbia Records"
  );

  let band5 = await bands.addBand(
    "The Beatles",
    ["John Lennon", "Paul McCartney", "George Harrison"],
    1960,
    ["American rock ‘n’ roll", "British pop"],
    "Tumultuous"
  );

  console.log("Done seeding database");
  await db.serverConfig.close();
};

main().catch(console.log);
