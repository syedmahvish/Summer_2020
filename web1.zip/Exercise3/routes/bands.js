const express = require("express");
const router = express.Router();
const dataObj = require("../data");
const bands = dataObj.bands;

router.get("/:id", async (req, res) => {
  if (!req.params.id) {
    res.status(404).json({ message: "Band Id not found" });
    return;
  }

  try {
    let bandData = await bands.getBand(req.params.id);
    res.json(bandData);
  } catch (error) {
    res.status(404).json({ message: "Band not found" });
  }
});

router.get("/", async (req, res) => {
  try {
    let allBandData = await bands.getAllBands();
    res.json(allBandData);
  } catch (error) {
    res.status(404).json({ message: "Band not found" });
  }
});

module.exports = router;
